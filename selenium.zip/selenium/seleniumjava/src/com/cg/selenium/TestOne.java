package com.cg.selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestOne {

	public static void main(String[] args) {
		
		//step-1(mandate)
		
		System.setProperty("webdriver.chrome.driver","D:\\topup\\selenium\\chromedriver.exe");
// step-2(mandate)
		WebDriver d= new ChromeDriver();
		d.get("http://www.google.com");
		
		
		
		
	}

}
