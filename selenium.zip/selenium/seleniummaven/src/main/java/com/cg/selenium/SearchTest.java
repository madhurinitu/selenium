package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SearchTest {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\topup\\selenium\\chromedriver.exe");
		WebDriver d= new ChromeDriver();
		d.get("http://www.google.com");
		WebElement e=d.findElement(By.name("q"));
		e.sendKeys("mobile phones under 10000");
		e.submit();
	
		d.get("http://www.amazon.com");
		//WebElement e1=d.findElement(By.name("q"));

		
		e.sendKeys("redmi6");
		e.submit();
		
	/*	d.get("http://localhost:4200/login");
		WebElement e=d.findElement(By.name("login"));
		e.click();
			 e=d.findElement(By.name("user"));
			e.sendKeys("madhuri");
			 e=d.findElement(By.name("pwd"));
			e.sendKeys("madhuri");
			 e=d.findElement(By.name("signin"));
			e.click();
			System.out.println(d.getTitle());*/
		
	}

}

