package com.cg.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class AmazonSignInTest {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\topup\\selenium\\chromedriver.exe");
		WebDriver d= new ChromeDriver();
		d.get("http://www.amazon.in");
		WebElement e=d.findElement(By.id("nav-link-yourAccount"));
		e.click();
		 
	//	d.navigate().to("https://www.amazon.com/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2F%3Fref_%3Dnav_signin&switch_account=");
		   e=d.findElement(By.name("email"));
			e.sendKeys("madhuri90221@gmail.com");
			 e=d.findElement(By.id("continue"));
				e.click();
			//	e.sendKeys("madhuri90221@gmail.com");
			      e=d.findElement(By.name("password"));
			e.sendKeys("Nithisha427@");
			    e=d.findElement(By.className("a-button-input"));
			e.click();
			//d.navigate().to("https://www.amazon.com/gp/flex/sign-out.html/ref=nav_youraccount_signout?ie=UTF8&action=sign-out&path=%2Fgp%2Fyourstore%2Fhome&signIn=1&useRedirectOnSuccess=1");
		 e=d.findElement(By.id("nav-link-yourAccount"));
			e.click();
		

			
			e=d.findElement(By.id("nav-item-signout"));
			
	}

}
