package com.cg.selenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;

public class DropDownTest {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver","D:\\topup\\selenium\\chromedriver.exe");

		WebDriver d= new ChromeDriver();
		d.get("http://localhost:4200");
		WebElement e=d.findElement(By.tagName("select"));
		Select s =new Select(e);
		s.selectByValue("java");
	e=d.findElement(By.partialLinkText("click"));
		e.click();
JavascriptExecutor js =(JavascriptExecutor)d;
js.executeScript("alert('hello,this is js executor')");
Alert a =d.switchTo().alert();
	}

}
